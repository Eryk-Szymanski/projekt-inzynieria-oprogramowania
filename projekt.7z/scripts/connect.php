<?php
    $mysqli = new mysqli("localhost", "root", "", "inzynieria-oprogramowania-db");
?>