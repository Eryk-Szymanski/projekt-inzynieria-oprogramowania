<?php

    class ClientAccount implements IAccount {
        public $name;
        public $surname;
        public $email;
        public $phone;
        public $password;
        public $address;
        public $order_ids;
    }

?>