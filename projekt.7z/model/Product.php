<?php

    class Product {
        public $id;
        public $name;
        public $weight;
        public $is_available;
        public $description;
        public $calories;
        public $price;
    }

?>