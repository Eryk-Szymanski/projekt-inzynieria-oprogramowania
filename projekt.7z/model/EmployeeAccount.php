<?php

    class EmployeeAccount implements IAccount {
        public $name;
        public $surname;
        public $email;
        public $phone;
        public $password;
        public $address;
    }

?>