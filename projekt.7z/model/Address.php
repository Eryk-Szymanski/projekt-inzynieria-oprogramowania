<?php

    class Address {
        public $zipcode;
        public $city;
        public $street;
        public $apartment;
    }

?>