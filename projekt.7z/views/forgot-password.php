<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-shop | Zapomnianie hasło</title>
  </head>
  <body>
    <div>
      <p>Zapomniane hasło? Tutaj możesz łatwo otrzymać nowe hasło.</p>
      <form action="recover-password.html" method="post">
        <input type="email">
        <button type="submit">Stwórz nowe hasło</button>
      </form>
      <p>
        <a href="../">Login</a>
      </p>
    </div>
  </body>
</html>
